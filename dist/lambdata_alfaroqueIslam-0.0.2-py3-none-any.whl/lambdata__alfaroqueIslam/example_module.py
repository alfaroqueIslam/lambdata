x = 2
def increment(number):
    return number + 1