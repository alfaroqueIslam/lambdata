# lambdata
A Python package with useful Data Science functions
