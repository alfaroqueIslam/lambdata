#!/usr/bin/env python
"""
lambdata - a collection of Data Science helper functions
"""
import pandas as pd
import numpy as np
TEST = pd.DataFrame(np.ones(10))
